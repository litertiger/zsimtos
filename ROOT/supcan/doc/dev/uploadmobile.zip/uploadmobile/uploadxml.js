﻿$(document).ready(function() {
	//注入函数=============
	$.fn.getv = function(isChk) {
		var v = null;
		if($(this).is('input')) {
			var stp = $(this).attr("type");
			if(stp == "checkbox")
				v = ($(this).is(':checked') == true) ? "1" : (isChk ? null : "0");
			else
				v = $(this).val();
		}
		else if($(this).is('td')) v = $(this).attr("val");
		else if($(this).is('select')) v = $(this).val();
		if(isChk == false) {
			if(v == null) v = "";
		}
		return v;
	};
	$.fn.hasInput = function() {
		var val = $(this).getv(true);
		if(val == null || val == "") return false;
		return true;
	};
	//注入下拉函数
	$.fn.sup_rebuildSelect = function(xmlstring) {
		$(this).empty();
		if(xmlstring == null) return;
		$(this).append("<option value=''></option>");
		$(this).append(xmlstring);
	};
	$.fn.sup_makeSelect_affect = function(parentkey) {	//依赖
		var xmlstring = null;
		if(parentkey != undefined && parentkey != null && parentkey != "") {
			var droplistName = $(this).attr("droplistName");
			xmlstring = sup_getDropXML(droplistName, parentkey);
		}
		$(this).sup_rebuildSelect(xmlstring);
	}
	$.fn.sup_emptylink = function() {  //清空链
		if($(this).is('select') == false) return;
		$(this).empty();
		try {
			$(this).selectmenu('refresh', true);
		}
		catch(e) {
		}
		var affectTo = $(this).attr("affectTo");
		if(affectTo == null) return;
		var arrId = affectTo.split(",");
		for(var n in arrId) $("#" + arrId[n]).sup_emptylink();
	};
	$.fn.sup_initSelect = function() {	//初始下拉
		var droplistName = $(this).attr("droplistName");
		if(droplistName == null) return true;

		var parentkey = null;
		var dependent = $(this).attr("dependent");
		if(dependent == null)
			parentkey = $(this).attr("dependentText");
		else
			parentkey = $("#" + dependent).getv(false);

		var xmlstring = sup_getDropXML(droplistName, parentkey);
		if(xmlstring == null) return true;
		$(this).sup_rebuildSelect(xmlstring);

		var v = $(this).attr("value");
		$(this).val(v);
		try {
			$(this).selectmenu('refresh', true);
		}
		catch(e) {
		}
	};

	//事件=============
	//下拉事件
	$("select").change(function() {
		var affectTo = $(this).attr("affectTo");
		if(affectTo == null) return;
		var key = $(this).val();
		var arrId = affectTo.split(",");
		for(var n in arrId) $("#" + arrId[n]).sup_emptylink();
		for(var n in arrId) $("#" + arrId[n]).sup_makeSelect_affect(key);
	});

	//上报的按钮事件: ajax 上报 XML 数据
	$("#idok").click(function() {
		var xml = Supcan_genXML();
		//alert(xml);
		$.ajax({url: SupcanUploadURL,  data: xml,  type: 'POST',  contentType: "text/xml",  dataType: "text",
			success : function(data) {
				if(data == "")
					alert("申请成功!	");
				else {  //验证未通过
					var cellname = "";
					var index = data.indexOf(":");
					if(index != -1) {
						cellname = data.substr(0, index);
						data = data.substring(index + 1);
					}
					alert(data);
					//焦点定位
					if(cellname != null) $("[cellname='" +cellname+ "']").focus().select();
				}
			},
			error : function(xhr, ajaxOptions, thrownError) { alert("提交失败: " + thrownError + "状态码: " + xhr.status); }
		});
	});

	//初始运行=========
	{
		//下拉初始
		var arrId = sup_select_seq.split(',');
		for(var n in arrId) $("#" + arrId[n]).sup_initSelect();
	}
});


///////////////////////////////////
//下拉数据及数据源管理
var sup_ds_map = {};	//下拉数据缓存
//取得下拉数据, key即关联参数, 也即数据源参数
function sup_getDropXML(droplistName, key)
{
	var obj = eval(droplistName);
	if(obj == null) return null;

	//先从缓存找
	if(key == null) key = "";
	var mapkey = droplistName + "#" + key;
	var xmlstring = sup_ds_map[mapkey];
	if(xmlstring != undefined) return xmlstring;

	//获取数据
	if(obj.listdata != undefined)
		xmlstring = sup_getXMLFromJson(obj, key);
	else if(obj.URL != undefined) {
		//拼装 URL
		var url = obj.URL + "?";
		for(var n in obj.paras) {
			var v = key;
			if(obj.paras[n].isPara == false) v = obj.paras[n].value;
			if(n > 0) url += "&";
			url += obj.paras[n].para + "=";
			url += encodeURIComponent(v);
		}
		//ajax访问数据源
		var xml_json = sup_ajax_dataSource(url);
		//自动识别数据格式 XML/JSON, 然后分别解析之
		if(xml_json.length > 2) {
			if(xml_json.substr(0, 1) == "<")
				xmlstring = sup_getXMLFromXML(xml_json, obj.dsdatacolumn, obj.dsdisplaycolumn);
			else {
				var jsonobj = jQuery.parseJSON(xml_json);
				xmlstring = sup_getXMLFromUnknownJson(jsonobj, obj.dsdatacolumn, obj.dsdisplaycolumn);
			}
		}
	}

	//存入缓存
	if(xmlstring == undefined) xmlstring = null;
	sup_ds_map[mapkey] = xmlstring;
	return xmlstring;
}
//json 对象 ==> Option XML
function sup_getXMLFromJson(jsonobj, parentkey)
{
	if(parentkey == undefined || parentkey == null) parentkey = "";
	var s = "";
	for(var n in jsonobj.listdata) {
		var key = jsonobj.listdata[n].key;
		var pkey = "";
		var index = key.indexOf("\\");
		if(index != -1) {
			pkey = key.substr(0, index);
			key = key.substring(index + 1);
		}
		if(pkey == parentkey) s += "<option value='"+key+"'>" +jsonobj.listdata[n].data+ "</option>";
	}
	return s;
}
//未知 json 格式对象 ==> Option XML
function sup_getXMLFromUnknownJson(obj, fieldname1, fieldname2) {
	var skey, svalue, sret = "";
	for(var name in obj) {
		var value = obj[name];
		if(typeof(value) == "object")
			sret += sup_getXMLFromUnknownJson(value, fieldname1, fieldname2);
		else {
			if(name == fieldname1) skey = value;
			if(name == fieldname2) svalue = value;
		}
	}
	if(skey == null) return sret;
	if(svalue == null) svalue = "";
	return sret + "<option value='"+skey+"'>" +svalue+ "</option>";
};

//ajax 访问数据源
function sup_ajax_dataSource(Url)
{
	var sret = "";
	$.ajax({type: "get", url: Url, async: false, contentType: "text/plain", dataType: "text",
		success: function (result) { sret = result;	},
		error: function (err) { alert("数据源返回错误:" + err); }
	});
  	return sret.trim();
}
//数据源 XMLJSON ==> Option XML
function sup_getXMLFromXML(xmlString, fieldKey, fieldValue)
{
	var ret = "";
	try {
		var domParser = new DOMParser();
		var xmlDoc = domParser.parseFromString(xmlString, 'text/xml');
 		var elements = xmlDoc.getElementsByTagName(fieldKey);
 		if(elements == null) return ret;
 		var record = elements[0].parentNode;
		while(record != null) {
			if(record.nodeType != 3) {
				var key = record.getElementsByTagName(fieldKey)[0].firstChild.nodeValue;
				var value = record.getElementsByTagName(fieldValue)[0].firstChild.nodeValue;
				ret += "<option value='"+key+"'>"+value+"</option>";
			}
			record = record.nextSibling;
		}
	}
	catch(e) {
		ret = "";
	}
	//alert(ret);
	return ret;
}


///////////////////////////////////
//如下为上报生成 XML 的功能
//XML Doc
var SupcanXmlDoc = null;

//生成XML串
function Supcan_genXML()
{
	SupcanXmlDoc = null;
	//data
	$("[id^=sup_dat_]").each(function() {
		if($(this).is("div")) return true;
		var val = $(this).getv(false);
		var cellname = $(this).attr("cellname");
		var id = $(this).attr("id").substring(8);
		if(cellname == null) cellname="";
		addToXML_Data(id, cellname, val);
	});

	//embed table
	var arrId = new Array();
	$("[id^=sup_embed_]").each(function() {
		if($(this).is("div")) return true;
		var id = $(this).attr("id").substring(10);
		arrId.push(id);
	});
	addToXML_EmbedTable(arrId);

	//生成XML串
	if(SupcanXmlDoc == null) return "";
	return new XMLSerializer().serializeToString(SupcanXmlDoc);
}

//自动生成DOM，并返回 WorkSpace节点
function getXMLWorkSheet()
{
	if(SupcanXmlDoc != null) return SupcanXmlDoc.getElementsByTagName("WorkSpace")[0];
	SupcanXmlDoc = document.implementation.createDocument('xml','',null);
	var worksheet = SupcanXmlDoc.createElement("WorkSpace");
	if(SupcanWorksheetName != undefined && SupcanWorksheetName != null) worksheet.setAttribute("name", SupcanWorksheetName);
	SupcanXmlDoc.appendChild(worksheet);
	return worksheet;
}

//添加<data>
function addToXML_Data(sname, cellname, sval, dispText)
{
	var worksheet = getXMLWorkSheet();
	var data = SupcanXmlDoc.createElement("data");
	data.setAttribute("name", sname);
	if(cellname != "") data.setAttribute("Cell", cellname);
	data.appendChild(SupcanXmlDoc.createTextNode(sval));
	worksheet.appendChild(data);
}

//添加<EmbedTable>
function addToXML_EmbedTable(arrId)
{
	while(arrId.length) {
		var s = arrId[0];
		arrId.shift();
		var index = s.indexOf("-");
		if(index == -1) continue;

		var sLeft = s.substr(0, index + 1);
		var EmbedTableId = s.substring(index + 1);
		index = EmbedTableId.indexOf("-");
		EmbedTableId = EmbedTableId.substr(0, index);
		
		var arrRecord = new Array();
		arrRecord.push(s);
		for(var i=0; i<arrId.length; i++) {
			s = arrId[i];
			index = s.indexOf("-");
			if(index == -1) continue;
			if(sLeft != s.substr(0, index + 1)) continue;
			arrRecord.push(s);
			arrId.splice(i, 1);
			i--;
		}
		addToEmbedRecord(EmbedTableId, arrRecord);
	}
}

//添加<EmbedTable>下的<Record>
function addToEmbedRecord(embedTableId, arrId)
{
	//本行是否有输入
	for(var i=0; i<arrId.length; i++) {
		var s = "#sup_embed_" + arrId[i];
		if($(s).hasInput()) break;
	}
	if(i >= arrId.length) return;
	
	//取得 embedTableId 的 <EmbedTable>
	var worksheet = getXMLWorkSheet();
	var embedTable = null;
	var nodeEmbedTable = worksheet.getElementsByTagName("EmbedTable");
	for(i = 0; i<nodeEmbedTable.length; i++) {
		var node = nodeEmbedTable[i];
		if(node.getAttribute("id") == embedTableId) {
			embedTable = node;
			break;
		}
	}
	if(embedTable == null) {
		embedTable = SupcanXmlDoc.createElement("EmbedTable");
		embedTable.setAttribute("id", embedTableId);
		worksheet.appendChild(embedTable);
	}

	//record
	var record = SupcanXmlDoc.createElement("record");
	embedTable.appendChild(record);
	for(i=0; i<arrId.length; i++) {
		var s = "#sup_embed_" + arrId[i];
		var val = $(s).getv(false);
		var cellname = $(s).attr("cellname");
		var index = s.lastIndexOf("-");
		s = s.substring(index + 1);
		var field = SupcanXmlDoc.createElement(s);
		if(cellname == null) cellname="";
		if(cellname != "") field.setAttribute("Cell", cellname);
		field.appendChild(SupcanXmlDoc.createTextNode(val));
		record.appendChild(field);
	}
}